/**
 * ==============================================================================
 * STUDENT PROFILE & ACADEMIC DASHBOARD (script.js)
 * Institution: Thiagarajar College, Madurai
 * Student: VAISHNAVI R (24UCS44)
 * ==============================================================================
 */

'use strict';

/* ==============================================================================
   SECTION 1: STUDENT PROFILE DATA (VAISHNAVI R)
   ============================================================================== */
const studentProfile = {
  fullName: "VAISHNAVI R",
  firstName: "VAISHNAVI",
  lastName: "R",
  title: "-",
  admissionNo: "14518",
  admissionYear: "2024-2025",
  rollNumber: "24UCS44",
  degree: "Undergraduate - AIDED",
  department: "Department of Computer Science",
  semester: "Semester-5",
  section: "SECTION A",
  courseName: "B.Sc. COMPUTER SCIENCE",
  collegeName: "Thiagarajar College",
  studentStatus: "Active",
  dob: "24-Dec-2006",
  age: "17",
  gender: "Female",
  fatherName: "RAMASAMY V",
  motherName: "R Amutha",
  address: "PLOT NO 1568, TNHB COLONY, MELA ANUPPANADI",
  city: "Madurai",
  state: "Tamil Nadu",
  academicYear: "2024-2027",
  academicBatch: "2026-2027",
  
  // High quality SVG profile photo matching Vaishnavi R (Screenshot 1: yellow kurti, white collar, neat parted dark hair)
  photoUrl: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 240" width="200" height="240">
    <defs>
      <linearGradient id="bgGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="%23dbeafe"/>
        <stop offset="100%" stop-color="%23eff6ff"/>
      </linearGradient>
      <linearGradient id="dressGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="%23eab308"/>
        <stop offset="100%" stop-color="%23ca8a04"/>
      </linearGradient>
      <linearGradient id="skinGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="%23d4a373"/>
        <stop offset="100%" stop-color="%23b8804c"/>
      </linearGradient>
    </defs>
    <rect width="200" height="240" rx="16" fill="url(%23bgGrad)"/>
    <!-- Hair Background -->
    <path d="M50 110 C50 50, 150 50, 150 110 C150 140, 140 160, 140 160 L60 160 C60 160, 50 140, 50 110 Z" fill="%231c1917"/>
    <!-- Neck -->
    <rect x="86" y="115" width="28" height="35" fill="url(%23skinGrad)"/>
    <!-- Shoulders & Yellow Kurti Dress -->
    <path d="M30 240 C30 160, 75 140, 100 140 C125 140, 170 160, 170 240 Z" fill="url(%23dressGrad)"/>
    <!-- White Dupatta / Shawl -->
    <path d="M45 240 C55 175, 75 155, 86 150 L95 180 L80 240 Z" fill="%23ffffff" opacity="0.95"/>
    <path d="M155 240 C145 175, 125 155, 114 150 L105 180 L120 240 Z" fill="%23ffffff" opacity="0.95"/>
    <!-- Face -->
    <ellipse cx="100" cy="98" rx="36" ry="44" fill="url(%23skinGrad)"/>
    <!-- Hair Front / Parting -->
    <path d="M64 88 C70 60, 100 62, 100 68 C100 62, 130 60, 136 88 C138 72, 132 58, 100 56 C68 58, 62 72, 64 88 Z" fill="%23171412"/>
    <path d="M64 88 C72 74, 90 70, 100 75 C100 75, 88 84, 82 92 Z" fill="%23171412"/>
    <!-- Small Bindi -->
    <circle cx="100" cy="86" r="2.5" fill="%2318181b"/>
    <!-- Eyebrows -->
    <path d="M78 88 Q88 84 95 87" stroke="%231c1917" stroke-width="2.5" stroke-linecap="round" fill="none"/>
    <path d="M105 87 Q112 84 122 88" stroke="%231c1917" stroke-width="2.5" stroke-linecap="round" fill="none"/>
    <!-- Eyes -->
    <ellipse cx="86" cy="95" rx="5" ry="3.5" fill="%23ffffff"/>
    <circle cx="86" cy="95" r="2.6" fill="%2318181b"/>
    <circle cx="87" cy="94" r="0.8" fill="%23ffffff"/>
    <ellipse cx="114" cy="95" rx="5" ry="3.5" fill="%23ffffff"/>
    <circle cx="114" cy="95" r="2.6" fill="%2318181b"/>
    <circle cx="115" cy="94" r="0.8" fill="%23ffffff"/>
    <!-- Nose -->
    <path d="M100 93 L98 108 L103 108" stroke="%239a5f33" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    <!-- Gentle Smile -->
    <path d="M91 117 Q100 125 109 117" stroke="%23881337" stroke-width="2.2" stroke-linecap="round" fill="none"/>
    <!-- Small Earrings -->
    <circle cx="62" cy="102" r="3" fill="%23fbbf24"/>
    <circle cx="138" cy="102" r="3" fill="%23fbbf24"/>
  </svg>`
};

/* ==============================================================================
   SECTION 2: EXACT ACADEMIC MARKS DATA (SEMESTERS 1 TO 4)
   ============================================================================== */
const academicData = {
  semesters: [
    {
      id: "sem1",
      name: "Semester 1",
      semesterCode: "Semester-1",
      creditsRegistered: 23,
      creditsCompleted: 23,
      subjects: [
        {
          code: "U24P1TA11",
          name: "POTHUTAMIL-I(TAMIL ILAKKIYA VARALARU-I)",
          internal: "24/25",
          internalObtained: 24,
          internalMax: 25,
          external: "57/75",
          externalObtained: 57,
          externalMax: 75,
          final: "81/100",
          finalObtained: 81,
          finalMax: 100,
          credit: 3,
          gradePoint: 8.1,
          grade: "A",
          status: "Pass"
        },
        {
          code: "U24P2EN11",
          name: "ENGLISH THROUGH PROSE",
          internal: "21/25",
          internalObtained: 21,
          internalMax: 25,
          external: "47/75",
          externalObtained: 47,
          externalMax: 75,
          final: "68/100",
          finalObtained: 68,
          finalMax: 100,
          credit: 3,
          gradePoint: 6.8,
          grade: "C",
          status: "Pass"
        },
        {
          code: "U24AEES11",
          name: "ENVIRONMENTAL STUDIES",
          internal: "14/15",
          internalObtained: 14,
          internalMax: 15,
          external: "30/35",
          externalObtained: 30,
          externalMax: 35,
          final: "44/50",
          finalObtained: 44,
          finalMax: 50,
          credit: 2,
          gradePoint: 8.8,
          grade: "A",
          status: "Pass"
        },
        {
          code: "UCS24CT11",
          name: "PROGRAMMING IN C",
          internal: "24/25",
          internalObtained: 24,
          internalMax: 25,
          external: "49/75",
          externalObtained: 49,
          externalMax: 75,
          final: "73/100",
          finalObtained: 73,
          finalMax: 100,
          credit: 4,
          gradePoint: 7.3,
          grade: "B",
          status: "Pass"
        },
        {
          code: "UCS24CT12",
          name: "DIGITAL PRINCIPLES & COMPUTER ORGANIZATION",
          internal: "22/25",
          internalObtained: 22,
          internalMax: 25,
          external: "49/75",
          externalObtained: 49,
          externalMax: 75,
          final: "71/100",
          finalObtained: 71,
          finalMax: 100,
          credit: 4,
          gradePoint: 7.1,
          grade: "B",
          status: "Pass"
        },
        {
          code: "UCS24CL11",
          name: "PROGRAMMING IN C LAB",
          internal: "40/40",
          internalObtained: 40,
          internalMax: 40,
          external: "58/60",
          externalObtained: 58,
          externalMax: 60,
          final: "98/100",
          finalObtained: 98,
          finalMax: 100,
          credit: 2,
          gradePoint: 9.8,
          grade: "O",
          status: "Pass"
        },
        {
          code: "UMA24GT11S",
          name: "DISCRETE MATHEMATICAL STRUCTURES",
          internal: "24/25",
          internalObtained: 24,
          internalMax: 25,
          external: "58/75",
          externalObtained: 58,
          externalMax: 75,
          final: "82/100",
          finalObtained: 82,
          finalMax: 100,
          credit: 5,
          gradePoint: 8.2,
          grade: "A",
          status: "Pass"
        }
      ]
    },
    {
      id: "sem2",
      name: "Semester 2",
      semesterCode: "Semester-2",
      creditsRegistered: 21,
      creditsCompleted: 21,
      subjects: [
        {
          code: "U24P1TA21",
          name: "POTHU TAMIL - II (TAMIL ILAKKIYAVARALARU - II)",
          internal: "23/25",
          internalObtained: 23,
          internalMax: 25,
          external: "51/75",
          externalObtained: 51,
          externalMax: 75,
          final: "74/100",
          finalObtained: 74,
          finalMax: 100,
          credit: 3,
          gradePoint: 7.4,
          grade: "B",
          status: "Pass"
        },
        {
          code: "U24P2EN21",
          name: "ENGLISH THROUGH FICTION",
          internal: "21/25",
          internalObtained: 21,
          internalMax: 25,
          external: "42/75",
          externalObtained: 42,
          externalMax: 75,
          final: "63/100",
          finalObtained: 63,
          finalMax: 100,
          credit: 3,
          gradePoint: 6.3,
          grade: "C",
          status: "Pass"
        },
        {
          code: "U24AEVE21",
          name: "VALUE EDUCATION",
          internal: "13/15",
          internalObtained: 13,
          internalMax: 15,
          external: "26/35",
          externalObtained: 26,
          externalMax: 35,
          final: "39/50",
          finalObtained: 39,
          finalMax: 50,
          credit: 2,
          gradePoint: 7.8,
          grade: "B",
          status: "Pass"
        },
        {
          code: "UCS24CT21",
          name: "JAVA PROGRAMMING",
          internal: "23/25",
          internalObtained: 23,
          internalMax: 25,
          external: "60/75",
          externalObtained: 60,
          externalMax: 75,
          final: "83/100",
          finalObtained: 83,
          finalMax: 100,
          credit: 4,
          gradePoint: 8.3,
          grade: "A",
          status: "Pass"
        },
        {
          code: "UCS24CL21",
          name: "JAVA PROGRAMMING LAB",
          internal: "38/40",
          internalObtained: 38,
          internalMax: 40,
          external: "59/60",
          externalObtained: 59,
          externalMax: 60,
          final: "97/100",
          finalObtained: 97,
          finalMax: 100,
          credit: 2,
          gradePoint: 9.7,
          grade: "O",
          status: "Pass"
        },
        {
          code: "UCS24CL22",
          name: "WEB TECHNOLOGY LAB",
          internal: "38/40",
          internalObtained: 38,
          internalMax: 40,
          external: "60/60",
          externalObtained: 60,
          externalMax: 60,
          final: "98/100",
          finalObtained: 98,
          finalMax: 100,
          credit: 2,
          gradePoint: 9.8,
          grade: "O",
          status: "Pass"
        },
        {
          code: "UMA24GT21S",
          name: "BASIC STATISTICS",
          internal: "22/25",
          internalObtained: 22,
          internalMax: 25,
          external: "64/75",
          externalObtained: 64,
          externalMax: 75,
          final: "86/100",
          finalObtained: 86,
          finalMax: 100,
          credit: 5,
          gradePoint: 8.6,
          grade: "A",
          status: "Pass"
        }
      ]
    },
    {
      id: "sem3",
      name: "Semester 3",
      semesterCode: "Semester-3",
      creditsRegistered: 22,
      creditsCompleted: 22,
      subjects: [
        {
          code: "UCS24CT31",
          name: "RELATIONAL DATABASE MANAGEMENT SYSTEMS",
          internal: "24/25",
          internalObtained: 24,
          internalMax: 25,
          external: "48/75",
          externalObtained: 48,
          externalMax: 75,
          final: "72/100",
          finalObtained: 72,
          finalMax: 100,
          credit: 4,
          gradePoint: 7.2,
          grade: "B",
          status: "Pass"
        },
        {
          code: "UCS24CT32",
          name: "DATA STRUCTURES AND ALGORITHMS",
          internal: "20/25",
          internalObtained: 20,
          internalMax: 25,
          external: "57/75",
          externalObtained: 57,
          externalMax: 75,
          final: "77/100",
          finalObtained: 77,
          finalMax: 100,
          credit: 4,
          gradePoint: 7.7,
          grade: "B",
          status: "Pass"
        },
        {
          code: "UCS24CL31",
          name: "RELATIONAL DATABASE MANAGEMENT SYSTEMS LAB",
          internal: "40/40",
          internalObtained: 40,
          internalMax: 40,
          external: "60/60",
          externalObtained: 60,
          externalMax: 60,
          final: "100/100",
          finalObtained: 100,
          finalMax: 100,
          credit: 2,
          gradePoint: 10,
          grade: "O",
          status: "Pass"
        },
        {
          code: "UCS24CL32",
          name: "DATA STRUCTURES LAB",
          internal: "40/40",
          internalObtained: 40,
          internalMax: 40,
          external: "59/60",
          externalObtained: 59,
          externalMax: 60,
          final: "99/100",
          finalObtained: 99,
          finalMax: 100,
          credit: 2,
          gradePoint: 9.9,
          grade: "O",
          status: "Pass"
        },
        {
          code: "UMA24GT31S",
          name: "COMPUTATIONAL METHODS",
          internal: "24/25",
          internalObtained: 24,
          internalMax: 25,
          external: "66/75",
          externalObtained: 66,
          externalMax: 75,
          final: "90/100",
          finalObtained: 90,
          finalMax: 100,
          credit: 5,
          gradePoint: 9,
          grade: "O",
          status: "Pass"
        },
        {
          code: "U24P1TA31",
          name: "POTHUTAMIL-III (TAMILAGA VARALARUM PANPADUM)",
          internal: "24/25",
          internalObtained: 24,
          internalMax: 25,
          external: "45/75",
          externalObtained: 45,
          externalMax: 75,
          final: "69/100",
          finalObtained: 69,
          finalMax: 100,
          credit: 3,
          gradePoint: 6.9,
          grade: "C",
          status: "Pass"
        },
        {
          code: "UZO24NT31",
          name: "BASICS IN APICULTURE",
          internal: "12/15",
          internalObtained: 12,
          internalMax: 15,
          external: "28/35",
          externalObtained: 28,
          externalMax: 35,
          final: "40/50",
          finalObtained: 40,
          finalMax: 50,
          credit: 2,
          gradePoint: 8,
          grade: "A",
          status: "Pass"
        }
      ]
    },
    {
      id: "sem4",
      name: "Semester 4",
      semesterCode: "Semester-4",
      creditsRegistered: 23,
      creditsCompleted: 23,
      subjects: [
        {
          code: "U24P1TA41",
          name: "POTHU TAMIL - IV (TAMIZHUM ARIVIYALUM)",
          internal: "23/25",
          internalObtained: 23,
          internalMax: 25,
          external: "50/75",
          externalObtained: 50,
          externalMax: 75,
          final: "73/100",
          finalObtained: 73,
          finalMax: 100,
          credit: 3,
          gradePoint: 7.3,
          grade: "B",
          status: "Pass"
        },
        {
          code: "UMA24NT41",
          name: "MATHEMATICS FOR COMPETITIVE EXAMINATIONS - II",
          internal: "12/15",
          internalObtained: 12,
          internalMax: 15,
          external: "30/35",
          externalObtained: 30,
          externalMax: 35,
          final: "42/50",
          finalObtained: 42,
          finalMax: 50,
          credit: 2,
          gradePoint: 8.4,
          grade: "A",
          status: "Pass"
        },
        {
          code: "UCS24CT41",
          name: "ADVANCED JAVA PROGRAMMING",
          internal: "21/25",
          internalObtained: 21,
          internalMax: 25,
          external: "63/75",
          externalObtained: 63,
          externalMax: 75,
          final: "84/100",
          finalObtained: 84,
          finalMax: 100,
          credit: 4,
          gradePoint: 8.4,
          grade: "A",
          status: "Pass"
        },
        {
          code: "UCS24CT42",
          name: "COMPUTER NETWORKS",
          internal: "24/25",
          internalObtained: 24,
          internalMax: 25,
          external: "54/75",
          externalObtained: 54,
          externalMax: 75,
          final: "78/100",
          finalObtained: 78,
          finalMax: 100,
          credit: 4,
          gradePoint: 7.8,
          grade: "B",
          status: "Pass"
        },
        {
          code: "UCS24CL41",
          name: "ADVANCED JAVA PROGRAMMING LAB",
          internal: "40/40",
          internalObtained: 40,
          internalMax: 40,
          external: "60/60",
          externalObtained: 60,
          externalMax: 60,
          final: "100/100",
          finalObtained: 100,
          finalMax: 100,
          credit: 2,
          gradePoint: 10,
          grade: "O",
          status: "Pass"
        },
        {
          code: "UCS24CL42",
          name: "PHP PROGRAMMING LAB",
          internal: "40/40",
          internalObtained: 40,
          internalMax: 40,
          external: "60/60",
          externalObtained: 60,
          externalMax: 60,
          final: "100/100",
          finalObtained: 100,
          finalMax: 100,
          credit: 2,
          gradePoint: 10,
          grade: "O",
          status: "Pass"
        },
        {
          code: "UMA24GT41S",
          name: "OPERATIONS RESEARCH",
          internal: "25/25",
          internalObtained: 25,
          internalMax: 25,
          external: "52/75",
          externalObtained: 52,
          externalMax: 75,
          final: "77/100",
          finalObtained: 77,
          finalMax: 100,
          credit: 5,
          gradePoint: 7.7,
          grade: "B",
          status: "Pass"
        },
        {
          code: "U24PVYRC41",
          name: "YOUTH RED CROSS SOCIETY",
          internal: "65/75",
          internalObtained: 65,
          internalMax: 75,
          external: "22/25",
          externalObtained: 22,
          externalMax: 25,
          final: "87/100",
          finalObtained: 87,
          finalMax: 100,
          credit: 1,
          gradePoint: 8.7,
          grade: "A",
          status: "Pass"
        }
      ]
    }
  ]
};

/* ==============================================================================
   SECTION 3: PERSONAL TRANSPORT DATA
   ============================================================================== */
const transportData = {
  transportMode: "Bike",
  startingPoint: "Home (Housing Board)",
  destination: "College Campus Gate & Student Drop-off Point",
  departureTime: "8:00 AM",
  expectedArrivalTime: "8:15 AM",
  approximateDuration: "15 Minutes",
  distanceCovered: "2 Km",
  
  routeSequence: [
    {
      stepNumber: 1,
      locationName: "Home (Housing Board)",
      time: "8:00 AM",
      description: "Started morning commute from residence."
    },
    {
      stepNumber: 2,
      locationName: "Cement Road",
      time: "8:05 AM",
      description: ""
    },
    {
      stepNumber: 3,
      locationName: "Major Traffic Junction (Pandian Nagar)",
      time: "8:10 AM",
      description: ""
    },
    {
      stepNumber: 4,
      locationName: "Theppakulam",
      time: "8:13 AM",
      description: ""
    },
    {
      stepNumber: 5,
      locationName: "College Campus Gate & Student Drop-off Point",
      time: "8:15 AM",
      description: "Arrived at the college campus."
    }
  ]
};

/* ==============================================================================
   ACADEMIC CALCULATIONS
   ============================================================================== */

/**
 * Calculates summary for a single semester
 */
function calculateSemesterSummary(subjects) {
  let totalMax = 0;
  let totalObtained = 0;
  let passedCount = 0;
  let failedCount = 0;
  let totalCredits = 0;
  let totalGradePoints = 0;

  subjects.forEach(subj => {
    totalMax += subj.finalMax;
    totalObtained += subj.finalObtained;
    totalCredits += subj.credit;
    totalGradePoints += subj.gradePoint * subj.credit;
    if (subj.status.toLowerCase() === "pass") {
      passedCount++;
    } else {
      failedCount++;
    }
  });

  const percentage = totalMax > 0 ? (totalObtained / totalMax) * 100 : 0;
  const gpa = totalCredits > 0 ? totalGradePoints / totalCredits : 0;

  return {
    totalMax,
    totalObtained,
    percentage: Number(percentage.toFixed(2)),
    gpa: Number(gpa.toFixed(2)),
    passedCount,
    failedCount,
    subjectCount: subjects.length,
    totalCredits
  };
}

/**
 * Calculates academic summary for a set of semesters (e.g. Year 1 or Year 2)
 */
function calculateYearlySummary(semesterList) {
  let totalMax = 0;
  let totalObtained = 0;
  let totalCredits = 0;
  let totalGradePoints = 0;
  let totalSubjects = 0;

  semesterList.forEach(sem => {
    sem.subjects.forEach(subj => {
      totalMax += subj.finalMax;
      totalObtained += subj.finalObtained;
      totalCredits += subj.credit;
      totalGradePoints += subj.gradePoint * subj.credit;
      totalSubjects++;
    });
  });

  const percentage = totalMax > 0 ? (totalObtained / totalMax) * 100 : 0;
  const gpa = totalCredits > 0 ? totalGradePoints / totalCredits : 0;

  return {
    totalMax,
    totalObtained,
    totalCredits,
    totalSubjects,
    percentage: Number(percentage.toFixed(2)),
    gpa: Number(gpa.toFixed(2))
  };
}

/**
 * Calculates cumulative overall performance across all semesters
 */
function calculateOverallPerformance(semesters) {
  let totalMax = 0;
  let totalObtained = 0;
  let totalSubjects = 0;
  let passedSubjects = 0;
  let failedSubjects = 0;
  let totalCreditsRegistered = 0;
  let totalCreditsCompleted = 0;

  semesters.forEach(sem => {
    totalCreditsRegistered += sem.creditsRegistered;
    totalCreditsCompleted += sem.creditsCompleted;

    sem.subjects.forEach(subj => {
      totalMax += subj.finalMax;
      totalObtained += subj.finalObtained;
      totalSubjects++;
      if (subj.status.toLowerCase() === "pass") {
        passedSubjects++;
      } else {
        failedSubjects++;
      }
    });
  });

  const overallPercentage = totalMax > 0 ? (totalObtained / totalMax) * 100 : 0;

  return {
    totalSubjects,
    totalMax,
    totalObtained,
    overallPercentage: Number(overallPercentage.toFixed(2)),
    totalCreditsRegistered,
    totalCreditsCompleted,
    passedSubjects,
    failedSubjects
  };
}

/* ==============================================================================
   DOM INITIALIZATION & EVENT HANDLERS
   ============================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  renderStudentProfile();
  renderAcademicPerformance();
  renderPersonalTransport();
  renderHomeSummary();
});

/**
 * Tab Navigation Controller
 */
function initNavigation() {
  const navLinks = document.querySelectorAll('.nav-link, .nav-action-btn');
  const sections = document.querySelectorAll('.dashboard-section');

  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('data-target');
      if (!targetId) return;

      document.querySelectorAll('.nav-link').forEach(nl => {
        if (nl.getAttribute('data-target') === targetId) {
          nl.classList.add('active');
        } else {
          nl.classList.remove('active');
        }
      });

      sections.forEach(sec => {
        if (sec.id === targetId) {
          sec.classList.add('active');
        } else {
          sec.classList.remove('active');
        }
      });

      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });
}

/**
 * Populate Home View Overview Cards
 */
function renderHomeSummary() {
  const overall = calculateOverallPerformance(academicData.semesters);

  const heroStudentName = document.getElementById('heroStudentName');
  if (heroStudentName) heroStudentName.textContent = studentProfile.fullName;

  const heroDepartment = document.getElementById('heroDepartment');
  if (heroDepartment) {
    heroDepartment.textContent = `${studentProfile.courseName} • ${studentProfile.department}`;
  }

  const homeOverallPct = document.getElementById('homeOverallPct');
  if (homeOverallPct) homeOverallPct.textContent = `${overall.overallPercentage}%`;

  const homeTotalSubjects = document.getElementById('homeTotalSubjects');
  if (homeTotalSubjects) homeTotalSubjects.textContent = `${overall.totalSubjects} Subjects`;

  const homeTransportSummary = document.getElementById('homeTransportSummary');
  if (homeTransportSummary) homeTransportSummary.textContent = transportData.transportMode;
}

/**
 * Module 1: Render Student Profile Section (Institutional Reference Design)
 */
function renderStudentProfile() {
  // Top bar user thumbnail and name
  const topUserThumbnail = document.getElementById('topUserThumbnail');
  if (topUserThumbnail) topUserThumbnail.src = studentProfile.photoUrl;

  const topUserName = document.getElementById('topUserName');
  if (topUserName) topUserName.textContent = studentProfile.fullName;

  // Banner student mini info
  const bannerStudentName = document.getElementById('bannerStudentName');
  if (bannerStudentName) bannerStudentName.textContent = studentProfile.fullName;

  const bannerPhoto = document.getElementById('bannerPhoto');
  if (bannerPhoto) bannerPhoto.src = studentProfile.photoUrl;

  const bannerCollegeName = document.getElementById('bannerCollegeName');
  if (bannerCollegeName) bannerCollegeName.textContent = studentProfile.collegeName;

  const bannerSubDetails = document.getElementById('bannerSubDetails');
  if (bannerSubDetails) {
    bannerSubDetails.textContent = `${studentProfile.semester} | ${studentProfile.section} | ${studentProfile.academicBatch}`;
  }

  // Main Profile Area
  const profilePhoto = document.getElementById('profilePhoto');
  if (profilePhoto) profilePhoto.src = studentProfile.photoUrl;

  const profileName = document.getElementById('profileName');
  if (profileName) profileName.textContent = studentProfile.fullName;

  // Aligned Grid for Primary Info
  const primaryDetailsContainer = document.getElementById('primaryDetailsContainer');
  if (primaryDetailsContainer) {
    primaryDetailsContainer.innerHTML = `
      <div class="field-row">
        <span class="field-label">STUDENT STATUS</span>
        <span class="field-colon">:</span>
        <span class="field-val"><span class="badge-status-active">${studentProfile.studentStatus}</span></span>
      </div>
      <div class="field-row">
        <span class="field-label">ADMISSION NO.</span>
        <span class="field-colon">:</span>
        <span class="field-val font-mono">${studentProfile.admissionNo}</span>
      </div>
      <div class="field-row">
        <span class="field-label">ADMISSION YEAR</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.admissionYear}</span>
      </div>
      <div class="field-row">
        <span class="field-label">ROLL NO.</span>
        <span class="field-colon">:</span>
        <span class="field-val font-mono">${studentProfile.rollNumber}</span>
      </div>
      <div class="field-row">
        <span class="field-label">DEGREE</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.degree}</span>
      </div>
      <div class="field-row">
        <span class="field-label">DEPARTMENT</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.department}</span>
      </div>
      <div class="field-row">
        <span class="field-label">SEMESTER</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.semester}</span>
      </div>
      <div class="field-row">
        <span class="field-label">SECTION</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.section}</span>
      </div>
      <div class="field-row">
        <span class="field-label">COURSE NAME</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.courseName}</span>
      </div>
      <div class="field-row">
        <span class="field-label">COLLEGE</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.collegeName}</span>
      </div>
    `;
  }

  // Personal Information Card (Screenshot 2 Alignment)
  const personalInfoContainer = document.getElementById('personalInfoDetailsContainer');
  if (personalInfoContainer) {
    personalInfoContainer.innerHTML = `
      <div class="field-row">
        <span class="field-label">TITLE</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.title}</span>
      </div>
      <div class="field-row">
        <span class="field-label">FIRST NAME</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.firstName}</span>
      </div>
      <div class="field-row">
        <span class="field-label">LAST NAME</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.lastName}</span>
      </div>
      <div class="field-row">
        <span class="field-label">DOB</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.dob}</span>
      </div>
      <div class="field-row">
        <span class="field-label">AGE</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.age}</span>
      </div>
      <div class="field-row">
        <span class="field-label">GENDER</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.gender}</span>
      </div>
      <div class="field-row">
        <span class="field-label">FATHER'S NAME</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.fatherName}</span>
      </div>
      <div class="field-row">
        <span class="field-label">MOTHER'S NAME</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.motherName}</span>
      </div>
      <div class="field-row">
        <span class="field-label">ADDRESS</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.address}</span>
      </div>
      <div class="field-row">
        <span class="field-label">CITY</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.city}</span>
      </div>
      <div class="field-row">
        <span class="field-label">STATE</span>
        <span class="field-colon">:</span>
        <span class="field-val">${studentProfile.state}</span>
      </div>
    `;
  }
}

/**
 * Module 2: Render Academic Performance & Exact Marks Tables
 */
function renderAcademicPerformance() {
  const semesters = academicData.semesters;
  const sem1 = semesters[0];
  const sem2 = semesters[1];
  const sem3 = semesters[2];
  const sem4 = semesters[3];

  const sem1Stats = calculateSemesterSummary(sem1.subjects);
  const sem2Stats = calculateSemesterSummary(sem2.subjects);
  const sem3Stats = calculateSemesterSummary(sem3.subjects);
  const sem4Stats = calculateSemesterSummary(sem4.subjects);

  const year1Stats = calculateYearlySummary([sem1, sem2]);
  const year2Stats = calculateYearlySummary([sem3, sem4]);
  const overallStats = calculateOverallPerformance(semesters);

  // Overall Performance Summary Card
  const overallPctDisplay = document.getElementById('overallPercentageValue');
  if (overallPctDisplay) overallPctDisplay.textContent = `${overallStats.overallPercentage}%`;

  const overallSubCount = document.getElementById('overallSubCount');
  if (overallSubCount) overallSubCount.textContent = overallStats.totalSubjects;

  const overallTotalMax = document.getElementById('overallTotalMax');
  if (overallTotalMax) overallTotalMax.textContent = overallStats.totalMax;

  const overallTotalObt = document.getElementById('overallTotalObt');
  if (overallTotalObt) overallTotalObt.textContent = overallStats.totalObtained;

  const overallCredits = document.getElementById('overallCredits');
  if (overallCredits) {
    overallCredits.textContent = `${overallStats.totalCreditsCompleted} / ${overallStats.totalCreditsRegistered}`;
  }

  const overallPassed = document.getElementById('overallPassed');
  if (overallPassed) overallPassed.textContent = overallStats.passedSubjects;

  const overallFailed = document.getElementById('overallFailed');
  if (overallFailed) overallFailed.textContent = overallStats.failedSubjects;

  // Bar Chart Comparison
  const chartContainer = document.getElementById('semesterBarChart');
  if (chartContainer) {
    const semData = [
      { name: "Sem 1", pct: sem1Stats.percentage },
      { name: "Sem 2", pct: sem2Stats.percentage },
      { name: "Sem 3", pct: sem3Stats.percentage },
      { name: "Sem 4", pct: sem4Stats.percentage }
    ];

    chartContainer.innerHTML = semData.map(item => `
      <div class="bar-column">
        <span class="bar-data-label">${item.pct}%</span>
        <div class="bar-fill-track">
          <div class="bar-fill-value" style="height: ${item.pct}%;" title="${item.name}: ${item.pct}%"></div>
        </div>
        <span class="bar-axis-label">${item.name}</span>
      </div>
    `).join('');
  }

  // Year 1 Performance Card
  const year1Card = document.getElementById('year1PerformanceCard');
  if (year1Card) {
    year1Card.innerHTML = `
      <div class="year-card-header">
        <h3>First Year Performance (Sem 1 & 2)</h3>
        <span class="badge-tag">Year 1</span>
      </div>
      <div class="info-list">
        <div class="info-item">
          <span class="info-label">Semester 1 Percentage</span>
          <span class="info-value font-bold">${sem1Stats.percentage}%</span>
        </div>
        <div class="info-item">
          <span class="info-label">Semester 2 Percentage</span>
          <span class="info-value font-bold">${sem2Stats.percentage}%</span>
        </div>
        <div class="info-item">
          <span class="info-label">First Year Overall Percentage</span>
          <span class="info-value font-bold text-blue-700">${year1Stats.percentage}%</span>
        </div>
        <div class="info-item">
          <span class="info-label">First Year Marks Obtained</span>
          <span class="info-value">${year1Stats.totalObtained} / ${year1Stats.totalMax}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Credits Completed</span>
          <span class="info-value font-bold">${year1Stats.totalCredits} / 44</span>
        </div>
      </div>
    `;
  }

  // Year 2 Performance Card
  const year2Card = document.getElementById('year2PerformanceCard');
  if (year2Card) {
    year2Card.innerHTML = `
      <div class="year-card-header">
        <h3>Second Year Performance (Sem 3 & 4)</h3>
        <span class="badge-tag">Year 2</span>
      </div>
      <div class="info-list">
        <div class="info-item">
          <span class="info-label">Semester 3 Percentage</span>
          <span class="info-value font-bold">${sem3Stats.percentage}%</span>
        </div>
        <div class="info-item">
          <span class="info-label">Semester 4 Percentage</span>
          <span class="info-value font-bold">${sem4Stats.percentage}%</span>
        </div>
        <div class="info-item">
          <span class="info-label">Second Year Overall Percentage</span>
          <span class="info-value font-bold text-blue-700">${year2Stats.percentage}%</span>
        </div>
        <div class="info-item">
          <span class="info-label">Second Year Marks Obtained</span>
          <span class="info-value">${year2Stats.totalObtained} / ${year2Stats.totalMax}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Credits Completed</span>
          <span class="info-value font-bold">${year2Stats.totalCredits} / 45</span>
        </div>
      </div>
    `;
  }

  // Render Detailed Semester Marks Tables with exact requested columns
  renderSemesterTables(semesters);
}

/**
 * Render Detailed Semester Tables
 * Columns: Semester, Course Code, Course Name, Internal Assessment Mark, External Assessment Mark, Final Assessment Mark, Credit, Grade Point, Grade, Result Status
 */
function renderSemesterTables(semesters) {
  const container = document.getElementById('semesterTablesContainer');
  if (!container) return;

  container.innerHTML = semesters.map((sem) => {
    const stats = calculateSemesterSummary(sem.subjects);

    const rowsHtml = sem.subjects.map(subj => {
      const isPass = subj.status.toLowerCase() === "pass";
      const resultBadge = isPass 
        ? `<span class="status-badge-pass">Pass</span>` 
        : `<span class="status-badge-fail">Fail</span>`;

      return `
        <tr>
          <td class="font-medium whitespace-nowrap">${sem.semesterCode}</td>
          <td><span class="code-badge">${subj.code}</span></td>
          <td class="course-name-cell">${subj.name}</td>
          <td class="text-center font-mono">${subj.internal}</td>
          <td class="text-center font-mono">${subj.external}</td>
          <td class="text-center font-mono font-bold">${subj.final}</td>
          <td class="text-center">${subj.credit}</td>
          <td class="text-center font-mono font-bold">${subj.gradePoint}</td>
          <td class="text-center font-bold">${subj.grade}</td>
          <td class="text-center">${resultBadge}</td>
        </tr>
      `;
    }).join('');

    return `
      <div class="semester-block" id="block-${sem.id}">
        <div class="semester-block-header">
          <div class="flex items-center gap-2">
            <span class="semester-icon">📚</span>
            <h3>${sem.name}</h3>
          </div>
          <div class="semester-header-badges">
            <span class="badge-tag">Registered: ${sem.creditsRegistered} Credits</span>
            <span class="badge-tag">Completed: ${sem.creditsCompleted} Credits</span>
            <span class="badge-tag font-bold text-blue-700">Percentage: ${stats.percentage}%</span>
          </div>
        </div>

        <div class="table-responsive">
          <table class="marks-table">
            <thead>
              <tr>
                <th>Semester</th>
                <th>Course Code</th>
                <th>Course Name</th>
                <th class="text-center">Internal Assessment Mark</th>
                <th class="text-center">External Assessment Mark</th>
                <th class="text-center">Final Assessment Mark</th>
                <th class="text-center">Credit</th>
                <th class="text-center">Grade Point</th>
                <th class="text-center">Grade</th>
                <th class="text-center">Result Status</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
            </tbody>
          </table>
        </div>

        <div class="semester-calc-footer">
          <div class="calc-metric-tile">
            <div class="tile-val">${stats.totalMax}</div>
            <div class="tile-lbl">Total Max Final Marks</div>
          </div>
          <div class="calc-metric-tile">
            <div class="tile-val">${stats.totalObtained}</div>
            <div class="tile-lbl">Final Marks Obtained</div>
          </div>
          <div class="calc-metric-tile">
            <div class="tile-val text-blue-700 font-bold">${stats.percentage}%</div>
            <div class="tile-lbl">Semester Percentage</div>
          </div>
          <div class="calc-metric-tile">
            <div class="tile-val">${sem.creditsCompleted}</div>
            <div class="tile-lbl">Credits Completed</div>
          </div>
          <div class="calc-metric-tile">
            <div class="tile-val text-green-700 font-bold">${stats.passedCount} / ${stats.subjectCount}</div>
            <div class="tile-lbl">Passed Subjects</div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

/**
 * Module 3: Render Transport (Bike Commute & Sequence)
 */
function renderPersonalTransport() {
  const summaryContainer = document.getElementById('transportSummaryCard');
  if (summaryContainer) {
    summaryContainer.innerHTML = `
      <h3>
        <span>🛵</span>
        <span>Transport Details</span>
      </h3>

      <div class="route-highlight-pills">
        <div class="route-pill-endpoint">
          <h4>${transportData.startingPoint}</h4>
          <span>Departure: ${transportData.departureTime}</span>
        </div>
        <div class="route-pill-arrow">➔</div>
        <div class="route-pill-endpoint">
          <h4>${transportData.destination}</h4>
          <span>Arrival: ${transportData.expectedArrivalTime}</span>
        </div>
      </div>

      <div class="info-list">
        <div class="info-item">
          <span class="info-label">Transport Mode</span>
          <span class="info-value font-bold text-blue-700">${transportData.transportMode}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Starting Point</span>
          <span class="info-value">${transportData.startingPoint}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Destination</span>
          <span class="info-value">${transportData.destination}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Departure Time</span>
          <span class="info-value font-mono font-bold">${transportData.departureTime}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Expected Arrival Time</span>
          <span class="info-value font-mono font-bold">${transportData.expectedArrivalTime}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Travel Duration</span>
          <span class="info-value font-bold text-green-700">${transportData.approximateDuration}</span>
        </div>
        <div class="info-item">
          <span class="info-label">Total Distance</span>
          <span class="info-value font-bold">${transportData.distanceCovered}</span>
        </div>
      </div>
    `;
  }

  // Sequence Timeline
  const timelineContainer = document.getElementById('routeTimelineContainer');
  if (timelineContainer) {
    const stepsHtml = transportData.routeSequence.map((step, idx) => {
      const isFirst = idx === 0;
      const isLast = idx === transportData.routeSequence.length - 1;
      const stepClass = isLast ? 'destination-step' : (isFirst ? 'completed' : '');

      return `
        <div class="timeline-step ${stepClass}">
          <div class="timeline-step-badge">${step.stepNumber}</div>
          <div class="timeline-step-content">
            <div class="timeline-step-top">
              <span class="timeline-loc-name">${step.locationName}</span>
              <span class="timeline-time-tag">${step.time}</span>
            </div>
            ${step.description ? `<p class="timeline-loc-desc">${step.description}</p>` : ''}
          </div>
        </div>
      `;
    }).join('');

    timelineContainer.innerHTML = `
      <h3>
        <span>🗺️</span>
        <span>Route Sequence</span>
      </h3>
      <div class="vertical-timeline">
        ${stepsHtml}
      </div>
    `;
  }
}
